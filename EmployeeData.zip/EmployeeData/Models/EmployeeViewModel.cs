﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeData.Models
{
    public class EmployeeViewModel
    {
        public int Id { get; set; }
        
        [DisplayName("FirstName")]
        public String FirstName { get; set; }
        
        [DisplayName("LastName")]
        public String LastName { get; set; }

        [DisplayName("DateOfBirth")]
        public DateTime DateOfBirth { get; set; }

        [DisplayName("E-mail")]
        public string Email { get; set; }
        public double Salary { get; set; }

        [DisplayName("Name")]
        public string FullName {
            get{ return FirstName+ " "+  LastName; } 
        }
    }
}
